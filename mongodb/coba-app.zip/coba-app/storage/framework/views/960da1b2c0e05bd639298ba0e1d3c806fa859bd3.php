<?php $__env->startSection('title','Edit User'); ?>

<?php $__env->startSection('content'); ?>
<div class="row gy-3">
    <div class="col">
        <div class="card shadow-sm p-4">
            <form action="<?php echo e(route('processEditUser')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <h1 class="mb-3 text-center">Edit User</h1>

                <input type="hidden" id="id" name="id" value="<?php echo e($user->id); ?>">

                <div class="form-floating mb-3">
                    <input type="text" class="form-control" placeholder="produk" id="produk" name="produk" value="<?php echo e($user->produk); ?>" required>
                    <label for="floatingInput">Produk</label>
                </div>    

                <div class="form-floating mb-3">
                    <input type="text" class="form-control" placeholder="stok" id="stok" name="stok" value="<?php echo e($user->stok); ?>"  required>
                    <label for="floatingInput">Stok</label>
                </div>
                
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" placeholder="harga" id="harga" name="harga" value="<?php echo e($user->harga); ?>"  required>
                    <label for="floatingInput">Harga</label>
                </div> 

                <button class="w-100 btn btn-lg btn-primary" type="submit">Submit</button>
            </form>    
        </div>    
    </div>    
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP1\htdocs\coba-app\resources\views/user/edit.blade.php ENDPATH**/ ?>