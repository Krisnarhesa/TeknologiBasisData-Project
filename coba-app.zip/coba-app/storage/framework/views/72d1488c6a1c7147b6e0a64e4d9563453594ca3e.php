<?php $__env->startSection('title','List Users'); ?>

<?php $__env->startSection('content'); ?>
<div class="row gy-3">
    <div class="col">
        <div class="card shadow-sm p-4">
            <div class="col-md-12 mb-4">
                <a href="<?php echo e(url('/add')); ?>"><button class="btn btn-primary text-end">Add</button></a>
            </div>
            <div class="col-md-12">
                <table class="table table-responsive">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Username</th>
                            <th scope="col">Email</th>
                            <th scope="col">Password</th>
                            <th scope="col">Alamat</th>
                            <th scope="col">No Telepon</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index+1); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->password); ?></td>
                                <td><?php echo e($user->alamat); ?></td>
                                <td><?php echo e($user->notelp); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/edit')); ?>/<?php echo e($user->id); ?>"><button class="btn btn-success">Edit</button></a>
                                    <a href="<?php echo e(route('processDeleteUser',$user->id)); ?>"><button class="btn btn-warning">Delete</button></a>

                                </td>
                            </tr>    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>    
                </table>   
            </div>    
        </div>    
    </div>    
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Semester 2\Teknologi Basis Data\UAS\coba-app\resources\views/user/index.blade.php ENDPATH**/ ?>