<?php $__env->startSection('title','List Users'); ?>

<?php $__env->startSection('content'); ?>
<div class="row gy-3">
    <div class="col">
        <div class="card shadow-sm p-4">
            <div class="col-md-12 mb-4">
                <a href="<?php echo e(url('/add')); ?>"><button class="btn btn-primary text-end">Add</button></a>
            </div>
            <div class="col-md-12">
                <table class="table table-responsive">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Produk</th>
                            <th scope="col">Stok</th>
                            <th scope="col">Harga</th>
                        </tr>    
                    </thead>   
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index+1); ?></td>
                                <td><?php echo e($user->produk); ?></td>
                                <td><?php echo e($user->stok); ?></td>
                                <td><?php echo e($user->harga); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/edit')); ?>/<?php echo e($user->id); ?>"><button class="btn btn-success">Edit</button></a>
                                    <a href="<?php echo e(route('processDeleteUser',$user->id)); ?>"><button class="btn btn-warning">Delete</button></a>

                                </td>
                            </tr>    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>    
                </table>   
            </div>    
        </div>    
    </div>    
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP1\htdocs\coba-app\resources\views/user/index.blade.php ENDPATH**/ ?>