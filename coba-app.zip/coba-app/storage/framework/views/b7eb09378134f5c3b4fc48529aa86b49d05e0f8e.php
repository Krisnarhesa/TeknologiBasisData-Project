<?php echo e($slot); ?>

<?php /**PATH C:\Semester 2\Teknologi Basis Data\UAS\coba-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>